# Backend

Node.js + Express API for the Agentic Lead Intel System.

## Run Locally

```bash
npm install
npm run dev
```

## Test

```bash
curl http://localhost:3000/health
```

```bash
curl -X POST http://localhost:3000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com","businessName":"Example Business","location":"Kansas City, MO"}'
```

## Production Start Command

```bash
npm start
```

## Build Command

No build command required.

## Required Runtime

Node 20 or later.
